package com.example.proyectofinal_2.modelos

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObjects
import com.google.firebase.ktx.Firebase

class PeliculaViewModel : ViewModel() {
    private val _peliculas = mutableStateOf<List<Pelicula>>(emptyList())
    val peliculas: State<List<Pelicula>>
        get() = _peliculas
    private val query = Firebase.firestore.collection("peliculas")
    init {
        query.addSnapshotListener { value, _ ->
            if (value != null) {
                _peliculas.value = value.toObjects()
            } //fin If
        } //fin Listener
    } //fin init
} //fin PlantaViewModel