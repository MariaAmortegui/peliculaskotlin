package com.example.proyectofinal_2.nav

import java.net.URLEncoder
import java.nio.charset.StandardCharsets

sealed class AppNav(val route: String) {
    object LoginScreen : AppNav(route = "LoginScreen")
    object Home : AppNav(route = "Home")
    object PeliculaLista : AppNav(route = "PeliculaLista")
    object AddScreen : AppNav(route = "AddScreen")
    object InfoPelicula :
        AppNav(route = "InfoPelicula/{foto}/{nombre}/{descripcion}/{url}") {
        fun String.encodeUrl() = URLEncoder.encode(this, StandardCharsets.UTF_8.toString())
        fun newroute(foto : String, nombre : String, descripcion: String, url : String): String {
            return "InfoPelicula/${foto.encodeUrl()}/$nombre/$descripcion/${url.encodeUrl()}"
        } // Fin new_route
    } // Fin InformacionPlanta
} // Fin AppNav
