package com.example.proyectofinal_2.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalFlorist
import androidx.compose.material.icons.filled.Spa
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.proyectofinal_2.modelos.Pelicula
import com.example.proyectofinal_2.modelos.PeliculaViewModel
import com.example.proyectofinal_2.nav.AppNav
import com.example.proyectofinal_2.ui.theme.Shapes

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun PeliculaLista(navController: NavController, viewModel: PeliculaViewModel) {
    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colors.primary)
                    .border(1.dp, color = Color.Black)
            ) {
                Text(
                    text = "MAINCINEMA",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    fontSize = 34.sp,
                    color = Color.Black
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { navController.navigate(AppNav.Home.route) }
                    ) {
                        Text(
                            text = "AGREGAR", color = MaterialTheme.colors.background
                        )
                    } // Fin Column
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { navController.navigate(AppNav.PeliculaLista.route) }

                    ) {
                        Text(
                            text = "MIS PELICULAS",
                            color = Color.Black,
                            fontWeight = FontWeight.Bol
                        ) // Fin Text
                    } // Fin Column
                } // Fin Row
            } // Fin Column Principal
        } // Fin topBar
    ) // Fin Scaffold
    {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colors.primary)
        ) {
            Column {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2)
                ) {
                    items(viewModel.peliculas.value) { pelicula ->
                        PlantaCard(pelicula, navController)
                    } // Fin Items
                } // Fin LazyColumn
            } // Fin Column-Box
        } // Fin Box
    } //Fin Scaffold
} // Fin JardinLista

@Composable
fun PlantaCard(pelicula: Pelicula, navController: NavController) {
    Card(
        modifier = Modifier
            .padding(all = 16.dp)
            .fillMaxSize()
            .border(3.dp, color = Color.Black, Shapes.small)
            .clickable {
                navController.navigate(
                    AppNav.InfoPelicula.newroute(
                        pelicula.foto,
                        pelicula.nombre,
                        pelicula.descripcion,
                        pelicula.url
                    )
                )
            } // Fin clickable
    ) //Fin Card
    {
        Column(
            modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = rememberAsyncImagePainter(pelicula.foto),
                contentDescription = "",
                modifier = Modifier.size(200.dp)
            ) // Fin Image
            Text(
                text = pelicula.nombre,
                color = Color.Black,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(5.dp),
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
            )
        } // Fin Column
    } // Fin Card
} // Fin PlantaCard