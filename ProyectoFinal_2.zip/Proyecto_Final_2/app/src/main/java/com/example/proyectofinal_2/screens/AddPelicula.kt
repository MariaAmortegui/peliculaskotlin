package com.example.proyectofinal_2.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.proyectofinal_2.modelos.Pelicula
import com.example.proyectofinal_2.nav.AppNav
import com.example.proyectofinal_2.R
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun AddScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar {
                Text(
                    text = "¡Agrega una pelicula!",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 30.sp,
                    color = Color.White
                )
            } // Fin TopAppBar
        }, // Fin topBar
        floatingActionButton = {
            FloatingActionButton(modifier = Modifier.size(32.dp),
                onClick = { navController.navigate(route = AppNav.Home.route) }) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Regresar",
                    tint = Color.White
                ) // Fin Icon
            } // Fin del FAB
        }, // Fin del FAb extreno
        floatingActionButtonPosition = FabPosition.End
    ) {
        BodyContent()
    } // Fin de BodyContent()
} // Fin AddScreen

@Composable
fun BodyContent() {
    var foto by remember { mutableStateOf("") }
    var nombre by remember { mutableStateOf("") }
    var descripcion by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(all = 30.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = nombre,
                    onValueChange = { nombre = it },
                    label = { Text("Nombre:") },
                )
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = foto,
                    onValueChange = { foto = it },
                    label = { Text("Foto:") },
                )
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = descripcion,
                    onValueChange = { descripcion = it },
                    label = { Text("Descripcion:") },
                )
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("URL:") },
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = {
                            val pelicula = Pelicula(foto, nombre, descripcion, url)
                            Firebase.firestore.collection("peliculas").add(pelicula)
                    }, //Fin onClick
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                        .fillMaxWidth()
                ) {
                    Text(text = "AGREGAR PELICULA")
                } // Fin Button
            } // Fin Item
        } // Fin LazyColumn
    } // Fin Box
} // Fin BodyContent


