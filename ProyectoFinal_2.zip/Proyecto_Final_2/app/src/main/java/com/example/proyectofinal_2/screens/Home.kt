package com.example.proyectofinal_2.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.Icon
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalFlorist
import androidx.compose.material.icons.filled.Spa
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.proyectofinal_2.nav.AppNav

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun Home(navController: NavController) {
    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colors.primary)
                    .border(1.dp, color = Color.Black)
            ) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "MAINCINEMA",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    fontSize = 34.sp,
                    color = Color.Black
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { navController.navigate(AppNav.Home.route) }
                    ) {
                        Text(text = "AGREGAR", color = Color.Black)
                    } // Fin Column
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { navController.navigate(AppNav.PeliculaLista.route) }
                    ) {
                        Text(
                            text = "MIS PELICULAS",
                            color = MaterialTheme.colors.background,
                            fontWeight = FontWeight.Bold
                        )
                    } // Fin Column Interno
                } // Fin Row
            } // Fin Column Principal
        } // Fin topBar
    ) {
        BodyContent(navController)
    } // Fin BodyContent
} // Fin Home

@Composable
fun BodyContent(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colors.primary),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "AGREGAR PELICULA",
            modifier = Modifier
                .clickable
                { navController.navigate(AppNav.AddScreen.route) }
                .background(Color.Yellow)
                .border(3.dp, color = Color.Black)
                .padding(5.dp)
        )
    } // Fin Column
} // Fin BodyContent
