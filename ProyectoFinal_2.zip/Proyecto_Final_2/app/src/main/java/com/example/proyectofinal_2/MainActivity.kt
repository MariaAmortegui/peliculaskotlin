package com.example.proyectofinal_2

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.runtime.livedata.observeAsState
import com.example.proyectofinal_2.modelos.PeliculaViewModel
import com.example.proyectofinal_2.nav.AppNavigation
import com.example.proyectofinal_2.screens.login.MainViewModel
import com.example.proyectofinal_2.ui.theme.ProyectoFinal_2Theme
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.tasks.Task

class MainActivity : ComponentActivity() {
    val viewModel by viewModels<PeliculaViewModel>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val viewModel: MainViewModel by viewModels()
            val isLoading by viewModel.isLoading().observeAsState(false)
            val condicional by viewModel.condicional().observeAsState(false)
            ProyectoFinal_2Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    AppNavigation(
                        condicional,
                        onClick = { viewModel.LoginWithGoogle(this@MainActivity) },
                        viewModel
                    ) // Fin AppNavigation
                } // Fin Surface
            } // Fin ProyectoFinal_2Theme
        } // Fin SetContent
    } // Fin onCreate

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val viewModel: MainViewModel by viewModels()
        if (requestCode == 1) {
            val task: Task<GoogleSignInAccount> = GoogleSignIn.getSignedInAccountFromIntent(data)
            viewModel.finishLogin(task)
        } //Fin If
    } // Fin onActivityResult
} // Fin onActivityResult